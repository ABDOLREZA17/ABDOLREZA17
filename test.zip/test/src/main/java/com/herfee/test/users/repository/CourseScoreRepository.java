package com.herfee.test.users.repository;

import com.herfee.test.users.entity.CourseScore;
import com.herfee.test.users.entity.CourseSelect;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseScoreRepository extends JpaRepository<CourseScore,Long> {

    List<CourseScore> findByCourseSelect_Students(Students students);
    List<CourseScore> findByCourseSelect_Course_Master(Master master);

}

package com.herfee.test.users.service;

import com.herfee.test.users.entity.Course;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.repository.CourseRepository;
import com.herfee.test.users.repository.MasterRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MasterServices implements UserDetailsService {

    private final MasterRepository masterRepository;

    public MasterServices(MasterRepository masterRepository, CourseRepository courseRepository) {
        this.masterRepository = masterRepository;
    }


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return masterRepository.findByEmail(email);
    }

    public Master findByEmail(String name) {
        return masterRepository.findByEmail(name);
    }


}

package com.herfee.test.users.service;

import com.herfee.test.users.entity.Course;
import com.herfee.test.users.entity.CourseSelect;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import com.herfee.test.users.repository.CourseSelectRepository;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.List;

@Service
public class CourseSelectService {

    private final CourseSelectRepository courseSelectRepository;

    public CourseSelectService(CourseSelectRepository courseSelectRepository) {
        this.courseSelectRepository = courseSelectRepository;
    }

    public CourseSelect save(CourseSelect select) {
        return courseSelectRepository.save(select);
    }



    public List<CourseSelect> findStudentCourse(Students email) {
        return courseSelectRepository.findByStudents(email);
    }

    public List<CourseSelect> findByMaster(Master master) {
        return courseSelectRepository.findByCourse_Master(master);
    }

    public CourseSelect findById(Long id) {
        return courseSelectRepository.findById(id).get();
    }
}

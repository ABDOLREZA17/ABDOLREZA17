package com.herfee.test.users.repository;

import com.herfee.test.users.entity.CourseSelect;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CourseSelectRepository extends JpaRepository<CourseSelect,Long> {

    List<CourseSelect> findByStudents(Students email);

    List<CourseSelect> findByCourse_Master(Master master);



}

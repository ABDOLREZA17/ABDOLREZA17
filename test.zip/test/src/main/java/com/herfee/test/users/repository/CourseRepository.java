package com.herfee.test.users.repository;

import com.herfee.test.users.entity.Course;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course,Long> {
//
//     Course findByMaster(Master master);
//
//     Course findAllById(Long id);


   List<Course> findByMaster(Master email);

}

package com.herfee.test.users.service;

import com.herfee.test.users.entity.Course;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.persistence.Id;
import java.security.Principal;
import java.util.List;

@Service
public class CourseServices {

    private final CourseRepository courseRepository;
    @Autowired
    public CourseServices(CourseRepository courseRepository) {
        this.courseRepository = courseRepository;
    }


    public Course save(Course courseForId) {
       return courseRepository.save(courseForId);

    }

    public Course findById(Long id) {
        return courseRepository.findById(id).get();
    }



    public List<Course> findAllCourse() {
        return courseRepository.findAll();
    }

    public List<Course> findByEmail(Master name) {
        return courseRepository.findByMaster(name);
    }
}

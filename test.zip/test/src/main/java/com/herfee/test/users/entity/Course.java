package com.herfee.test.users.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;


@Entity
public class Course{

    @Id
    @GeneratedValue
    private Long id;
    private String courseName;
    private Integer courseCod;

    @ManyToOne()
    private Master master;


    public Course(String courseName, Integer courseCod, Master master) {
        this.courseName = courseName;
        this.courseCod = courseCod;
        this.master = master;
    }

    public Integer getCourseCod() {
        return courseCod;
    }

    public void setCourseCod(Integer courseCod) {
        this.courseCod = courseCod;
    }



    public Master getMaster() {
        return master;
    }

    public void setMaster(Master master) {
        this.master = master;
    }

    public Course() {
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}

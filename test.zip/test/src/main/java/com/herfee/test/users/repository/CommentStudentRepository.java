package com.herfee.test.users.repository;

import com.herfee.test.users.entity.CommentStudent;
import com.herfee.test.users.entity.CourseScore;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommentStudentRepository extends JpaRepository<CommentStudent,Long> {

    //List<CommentStudent> findBySender(String id);

    List<CommentStudent> findByCourseScore_CourseSelect_Students(Students students);
    List<CommentStudent> findByCourseScore_CourseSelect_Course_Master(Master master);
}
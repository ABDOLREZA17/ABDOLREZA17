package com.herfee.test.config;

import com.herfee.test.jwt.JwtFilterMaster;
import com.herfee.test.users.service.MasterServices;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@Order(10)
public class MasterConfig extends WebSecurityConfigurerAdapter {
    private final MasterServices masterServices;
    private final JwtFilterMaster jwtFilter;

    public MasterConfig(MasterServices masterServices, JwtFilterMaster jwtFilter) {
        this.masterServices = masterServices;
        this.jwtFilter = jwtFilter;
    }


    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable()
                .antMatcher("/master/**")
                .authorizeRequests()
                .antMatchers("/master/masterlogin","/v2/api-docs","/configuration/ui",
                        "/swagger-resources/**","/configuration/security","/swagger-ui.html","/webjars/**").permitAll()
                .anyRequest().authenticated()
                .and()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(masterServices);
    }

    @Override
    @Bean("masterManager")
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }
}


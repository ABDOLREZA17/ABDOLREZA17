package com.herfee.test.users.entity;

import javax.persistence.*;

@Entity
public class CommentStudent {
    @Id
    @GeneratedValue
    private Long id;

    @OneToOne
    private CourseScore courseScore;

    private String comment;
    private String sender;

    public CommentStudent(CourseScore courseScore, String comment, String sender) {
        this.courseScore = courseScore;
        this.comment = comment;
        this.sender = sender;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public CourseScore getCourseScore() {
        return courseScore;
    }

    public void setCourseScore(CourseScore courseScore) {
        this.courseScore = courseScore;
    }



    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public CommentStudent() {
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


}

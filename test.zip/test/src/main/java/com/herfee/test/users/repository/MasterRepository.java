package com.herfee.test.users.repository;

import com.herfee.test.users.entity.Master;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MasterRepository extends JpaRepository<Master,Long> {


    Master findByEmail(String email);

}

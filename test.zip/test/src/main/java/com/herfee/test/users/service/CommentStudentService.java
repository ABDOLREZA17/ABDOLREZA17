package com.herfee.test.users.service;

import com.herfee.test.users.entity.CommentStudent;
import com.herfee.test.users.entity.CourseScore;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import com.herfee.test.users.repository.CommentStudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentStudentService {
    private final CommentStudentRepository commentStudentRepository;
    @Autowired
    public CommentStudentService(CommentStudentRepository commentStudentRepository) {
        this.commentStudentRepository = commentStudentRepository;
    }

    public CommentStudent addComment(CommentStudent commentStudent) {
        return commentStudentRepository.save(commentStudent);
    }

    public List<CommentStudent> findStudentComment(Students students) {
        return commentStudentRepository.findByCourseScore_CourseSelect_Students(students);
    }

    public List<CommentStudent> findMasterComment(Master master) {
        return commentStudentRepository.findByCourseScore_CourseSelect_Course_Master(master);
    }


}

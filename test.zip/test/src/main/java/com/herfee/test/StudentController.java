package com.herfee.test;

import com.herfee.test.jwt.JwtAuth;
import com.herfee.test.jwt.JwtUtils;
import com.herfee.test.users.entity.*;
import com.herfee.test.users.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {


    private final AuthenticationManager authenticationManager;
    private  final StudentServices studentServices;
    private final CourseServices courseServices;
    private final CourseSelectService courseSelectService;
    private final CommentStudentService commentStudentService;
    private final CourseScoreService courseScoreService;

    private final JwtUtils jwtUtils;

    @Autowired
    public StudentController(@Qualifier("StudentManager") AuthenticationManager authenticationManager,
                             StudentServices studentServices, CourseServices courseServices,
                             CourseSelectService courseSelectService
            , CommentStudentService commentStudentService, CourseScoreService courseScoreService, JwtUtils jwtUtils) {
        this.authenticationManager = authenticationManager;
        this.studentServices = studentServices;
        this.courseServices = courseServices;
        this.courseSelectService = courseSelectService;
        this.commentStudentService = commentStudentService;
        this.courseScoreService = courseScoreService;
        this.jwtUtils = jwtUtils;
    }

    @PostMapping("/studentlogin")
    public ResponseEntity<Void> login(@RequestBody JwtAuth jwtAuth, HttpServletResponse httpServletResponse) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken
                    (jwtAuth.getUsername(), jwtAuth.getPassword()));

        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
        httpServletResponse.addHeader("Authorization",jwtUtils.createToken(jwtAuth.getUsername()));
        return ResponseEntity.ok().build();
    }


    @PostMapping("courseSelect")
    public CourseSelect courseSelect(@RequestBody CourseSelect courseSelect, Principal principal){
        CourseSelect select=new CourseSelect();
        Students students= studentServices.findByEmail(principal.getName());
        select.setStudents(students);
        Course course=courseServices.findById(courseSelect.getId());
        select.setCourse(course);
        return  courseSelectService.save(select);
    }

    @GetMapping("studentCourses")
    public  List<CourseSelect> showStudentCourses(Principal principal){
        Students students = studentServices.findByEmail(principal.getName());
        return courseSelectService.findStudentCourse(students);
    }




    @GetMapping("allCourses")
    public List<Course> showCourses(){
        return courseServices.findAllCourse();
    }



    @GetMapping("studentScore")
    public List<CourseScore> studentScore(Principal principal){
        Students students=studentServices.findByEmail(principal.getName());
        List<CourseScore> courseScores=courseScoreService.findStudentScore(students);
        return courseScores;

    }
    @PostMapping("addComment")
    public CommentStudent addComment(@RequestBody CommentStudent commentStudent,Principal principal){
        CommentStudent commentStudent1=new CommentStudent();
        CourseScore courseScore=courseScoreService.findById(commentStudent.getCourseScore().getId());
        commentStudent1.setCourseScore(courseScore);
        commentStudent1.setComment(commentStudent.getComment());
        Students students=studentServices.findByEmail(principal.getName());
        commentStudent1.setSender(students.getEmail());

        return commentStudentService.addComment(commentStudent1) ;
    }


    @GetMapping("showComment")
    public List<CommentStudent> showComment(Principal principal){
        Students students=studentServices.findByEmail(principal.getName());
        return commentStudentService.findStudentComment(students);

    }





}

package com.herfee.test.jwt;

import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import com.herfee.test.users.service.MasterServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class JwtFilterMaster extends OncePerRequestFilter {

    private final JwtUtils jwtUtils;
    private final MasterServices masterServices;
    @Autowired
    public JwtFilterMaster(JwtUtils jwtUtils, MasterServices masterServices) {
        this.jwtUtils = jwtUtils;
        this.masterServices = masterServices;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest
            , HttpServletResponse httpServletResponse, FilterChain filterChain)
            throws ServletException, IOException {

        String jwtHeader=httpServletRequest.getHeader("Authorization");
        if (jwtHeader!=null) {
            String username = jwtUtils.getUsername(jwtHeader);
            if (username!=null && SecurityContextHolder.getContext().getAuthentication()==null) {
                Master master = (Master) masterServices.loadUserByUsername(username);
                if (master!=null){
                    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken=new
                    UsernamePasswordAuthenticationToken(master,null,
                    master.getAuthorities());
                    SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
                }
            }
        }
        filterChain.doFilter(httpServletRequest,httpServletResponse);
    }



}

package com.herfee.test.users.service;

import com.herfee.test.users.entity.CourseScore;
import com.herfee.test.users.entity.CourseSelect;
import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import com.herfee.test.users.repository.CourseScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseScoreService {
    private final CourseScoreRepository courseScoreRepository;
    @Autowired
    public CourseScoreService(CourseScoreRepository courseScoreRepository) {
        this.courseScoreRepository = courseScoreRepository;
    }


    public CourseScore addCourseScore(CourseScore courseScore) {
        return courseScoreRepository.save(courseScore);
    }

    public CourseScore findById(Long id) {
        return courseScoreRepository.findById(id).get();
    }

    public List<CourseScore> findStudentScore(Students students) {
        return courseScoreRepository.findByCourseSelect_Students(students);
    }

    public List<CourseScore> findScoreToMaster(Master master) {
        return courseScoreRepository.findByCourseSelect_Course_Master(master);
    }
}

package com.herfee.test.users.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CourseScore {

    @Id
    @GeneratedValue
    private Long id;
    @OneToOne
    private CourseSelect courseSelect;
    private Float score;


    public CourseScore(CourseSelect courseSelect, Float score) {
        this.courseSelect = courseSelect;
        this.score = score;
    }



    public CourseSelect getCourseSelect() {
        return courseSelect;
    }

    public void setCourseSelect(CourseSelect courseSelect) {
        this.courseSelect = courseSelect;
    }


    public Float getScore() {
        return score;
    }

    public void setScore(Float score) {
        this.score = score;
    }






    public CourseScore() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


}

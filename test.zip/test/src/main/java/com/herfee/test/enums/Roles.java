package com.herfee.test.enums;

import org.springframework.security.core.GrantedAuthority;

public enum Roles implements GrantedAuthority {

    STUDENT,
    MASTER;

    @Override
    public String getAuthority() {
        return this.name();
    }
}

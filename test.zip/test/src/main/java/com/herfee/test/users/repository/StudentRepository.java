package com.herfee.test.users.repository;

import com.herfee.test.users.entity.Master;
import com.herfee.test.users.entity.Students;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Students,Long> {

    Students findByEmail(String email);

}

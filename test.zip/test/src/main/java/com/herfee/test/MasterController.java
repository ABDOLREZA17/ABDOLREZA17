package com.herfee.test;

import com.herfee.test.jwt.JwtAuth;
import com.herfee.test.jwt.JwtUtils;
import com.herfee.test.users.entity.*;
import com.herfee.test.users.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping(value = "/master")
public class MasterController {

    //Dao 
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final CourseServices courseServices;
    private final MasterServices masterServices;
    private final CourseSelectService courseSelectService;
    private final CourseScoreService courseScoreService;
    private final CommentStudentService commentStudentService;

    @Autowired
    public MasterController(@Qualifier("masterManager") AuthenticationManager authenticationManager,
                            JwtUtils jwtUtils, CourseServices courseServices, MasterServices masterServices,
                            CourseSelectService courseSelectService, CourseScoreService courseScoreService, CommentStudentService commentStudentService) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
        this.courseServices = courseServices;
        this.masterServices = masterServices;
        this.courseSelectService = courseSelectService;
        this.courseScoreService = courseScoreService;
        this.commentStudentService = commentStudentService;
    }

    @PostMapping(value = "/masterlogin")
    public ResponseEntity<Void> login(@RequestBody JwtAuth jwtAuth, HttpServletResponse httpServletResponse) {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken
                    (jwtAuth.getUsername(), jwtAuth.getPassword()));

        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
        httpServletResponse.addHeader("Authorization", jwtUtils.createToken(jwtAuth.getUsername()));
        return ResponseEntity.ok().build();

    }




    @PostMapping("/addCourse")
    public Course addLesson(@RequestBody Course course, Principal principal) {
        Course courseForId = new Course();

        Master master= masterServices.findByEmail(principal.getName());

        courseForId.setMaster(master);
        courseForId.setCourseCod(course.getCourseCod());
        courseForId.setCourseName(course.getCourseName());

       return courseServices.save(courseForId);
    }

    @GetMapping("masterCourses")
    public List<Course> masterAddCourse(Principal principal){
        Master master=masterServices.findByEmail(principal.getName());
        return courseServices.findByEmail(master);

        }


    @GetMapping("allCourses")
    public List<Course> showCourses(){
        return courseServices.findAllCourse();
    }

    @GetMapping("studentsAnyCourse")
    public List<CourseSelect> studentsAnyCourse(Principal principal) {
        Master master=masterServices.findByEmail(principal.getName());
        return courseSelectService.findByMaster(master);

    }
//    @PostMapping("showCommentCourses")
//    public List<CommentStudent> showCommentCourse(Principal principal){
//
//        Master master=masterServices.findByEmail(principal.getName());
//        return commentStudentService.findCourseComment(master);
//
//    }
//    @PostMapping("answerStudentComment")
//    public List<CommentStudent> answerStudentComment(@RequestBody CommentStudent commentStudent){
//        CommentStudent commentStudent1=new CommentStudent();
//        commentStudent1.setCourse(commentStudent.getCourse());
//        commentStudent1.setComment(commentStudent.getComment());
//        return commentStudentService.findCourseReplyComment(commentStudent1);
//
//
//
//    }

    @PostMapping("addScore")
    public CourseScore addCourseScore(@RequestBody CourseScore courseScore){
        CourseScore courseScore1=new CourseScore();

        CourseSelect courseSelect=courseSelectService.findById(courseScore.getCourseSelect().getId());
        //System.out.println(courseSelect.getCourse().getCourseName());

        courseScore1.setCourseSelect(courseSelect);
       // System.out.println(courseScore1.getCourseSelect().getCourse().getId());
        courseScore1.setScore(courseScore.getScore());
       // System.out.println(courseScore1.getId());


        return courseScoreService.addCourseScore(courseScore1);

    }
    @PostMapping("answerComment")
    public CommentStudent addComment(@RequestBody CommentStudent commentStudent,Principal principal){
        CommentStudent commentStudent1=new CommentStudent();


        CourseScore courseScore=courseScoreService.findById(commentStudent.getCourseScore().getId());
        commentStudent1.setCourseScore(courseScore);
        commentStudent1.setComment(commentStudent.getComment());
        //commentStudent1.setRole("Master");
        Master master=masterServices.findByEmail(principal.getName());
        commentStudent1.setSender(master.getEmail());

        return commentStudentService.addComment(commentStudent1) ;

    }

    @GetMapping("showComment")
    public List<CommentStudent> showComment(Principal principal){
        Master master=masterServices.findByEmail(principal.getName());
        return commentStudentService.findMasterComment(master);
    }

    @GetMapping("showScore")
    public List<CourseScore> showScore(Principal principal){
        Master master=masterServices.findByEmail(principal.getName());
        return courseScoreService.findScoreToMaster(master);

    }






    }




package com.herfee.test.users.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class CourseSelect {

    @Id
    @GeneratedValue
    private Long id;

    @OneToOne
    private Course course;

    @OneToOne
    private Students students;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public Students getStudents() {
        return students;
    }

    public void setStudents(Students students) {
        this.students = students;
    }

    public CourseSelect(Course course, Students students) {
        this.course = course;
        this.students = students;
    }

    public CourseSelect() {

    }
}
